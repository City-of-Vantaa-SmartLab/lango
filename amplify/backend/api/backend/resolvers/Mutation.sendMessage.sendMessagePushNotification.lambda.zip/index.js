const AWS = require('aws-sdk');

const sns = new AWS.SNS();

// TODO: Move to envvar or similar
const PLATFORM_APPLICATION_ARN = 'arn:aws:sns:eu-central-1:876630367030:app/GCM/lango-push-notifications';

async function createEndpoint(token) {
  const params = {
    PlatformApplicationArn: PLATFORM_APPLICATION_ARN,
    Token: token,
  };

  return new Promise((resolve, reject) => {
    sns.createPlatformEndpoint(params, (err, data) => {
      if (err) {
        reject(new Error(`Creating endpoint failed: ${err.toString()}`));
        return;
      }

      resolve(data.EndpointArn);
    });
  });
}

async function sendPushNotification(endpointArn, eventData) {
  const params = {
    Message: JSON.stringify({
      default: `Uusi viesti käyttäjältä ${eventData.senderFirstName}`,
      GCM: JSON.stringify({
        data: {
          friendshipId: eventData.friendshipId,
          senderFirstName: eventData.senderFirstName,
          message: eventData.message.slice(0, 100),
        },
      }),
    }),
    MessageStructure: 'json',
    TargetArn: endpointArn,
  };

  return new Promise((resolve, reject) => {
    sns.publish(params, (err) => {
      if (err) {
        reject(new Error(`Sending push notification failed: ${err.toString()}`));
        return;
      }

      resolve();
    });
  });
}

exports.handler = async function handler(event) {
  const missingFields = [];
  if (!event.friendshipId) {
    missingFields.push('friendshipId');
  }
  if (!event.senderFirstName) {
    missingFields.push('senderFirstName');
  }
  if (!event.message) {
    missingFields.push('message');
  }
  if (!event.receiverPushToken) {
    missingFields.push('receiverPushToken');
  }

  if (missingFields.length > 0) {
    console.error(`The following fields are missing from the event: ${missingFields.join(', ')}`);
    return;
  }

  const endpointArn = await createEndpoint(event.receiverPushToken);
  await sendPushNotification(endpointArn, event);
};
